//
//  AppDelegate.m
//  MultipleStoryboards
//
//  Created by Adam Wallraff on 7/14/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    UITabBarController *rootTabBarController = [[UITabBarController alloc]init];
    
    UIStoryboard *firstTabSB = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIStoryboard *secondTabSB = [UIStoryboard storyboardWithName:@"SecondTab" bundle:nil];

    UIViewController *firstVC = [firstTabSB instantiateInitialViewController];
    firstVC.title = @"First View Controller";
    
    UIViewController *secondVC = [secondTabSB instantiateInitialViewController];
    secondVC.title = @"Second View Controller";

    
    rootTabBarController.viewControllers = @[firstVC, secondVC];
    
    self.window.rootViewController = rootTabBarController;
    
    
    
    return YES;
}


@end
