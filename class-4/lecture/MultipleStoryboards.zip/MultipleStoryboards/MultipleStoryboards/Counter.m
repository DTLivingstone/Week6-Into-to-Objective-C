//
//  Counter.m
//  MultipleStoryboards
//
//  Created by Adam Wallraff on 7/14/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import "Counter.h"

@implementation Counter


-(void)incrementCounter{
    
    if (self.count % 3 == 0) {
        [self willChangeValueForKey:@"count"];
        self.count++;
        [self didChangeValueForKey:@"count"];
        
    } else{
        self.count++;
    }
    
    
}

+(BOOL)automaticallyNotifiesObserversOfCount{
    
    return NO;
    
}


@end
