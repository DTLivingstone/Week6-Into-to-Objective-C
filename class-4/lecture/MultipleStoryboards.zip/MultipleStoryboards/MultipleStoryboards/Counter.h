//
//  Counter.h
//  MultipleStoryboards
//
//  Created by Adam Wallraff on 7/14/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Counter : NSObject

@property NSInteger count;

-(void)incrementCounter;

@end
