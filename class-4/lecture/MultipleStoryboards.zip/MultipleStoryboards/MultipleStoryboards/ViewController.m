//
//  ViewController.m
//  MultipleStoryboards
//
//  Created by Adam Wallraff on 7/14/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

#import "ViewController.h"
#import "Counter.h"


static void *counterContext = &counterContext;

@interface ViewController ()

@property(strong, nonatomic)Counter *counter;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.counter = [[Counter alloc]init];
//
//    NSLog(@"%ld", self.counter.count);
//    
    [self setValue:@100 forKeyPath:@"counter.count"];
//
//    NSLog(@"%ld", self.counter.count);
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self addObserver:self forKeyPath:@"self.counter.count" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:&counterContext];
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [self removeObserver:self forKeyPath:@"self.counter.count"];
}

- (IBAction)incrementPressed:(id)sender {
    
    [self.counter incrementCounter];
    
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    
    if (context == counterContext){
        
        NSLog(@"%ld", self.counter.count);
        
        
    }else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
    
}


@end













