//
//  CloudService.h
//  ClassMates
//
//  Created by Michael Babiy on 7/14/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

@import Foundation;
@import CloudKit;
@class Student;

typedef enum : NSUInteger
{
    CloudOperationSave = 0,
    CloudOperationRetrive,
    CloudOperationDelete,
} CloudOperation;

typedef void(^CloudServiceCompletion)(BOOL success, NSArray<Student *> *students);

@interface CloudService : NSObject

+ (instancetype)shared;

- (void)enqueueOperation:(CloudServiceCompletion)completion;
- (void)enqueueOperation:(CloudOperation)operation student: (Student *)student completion:(CloudServiceCompletion)comletion;

@end
