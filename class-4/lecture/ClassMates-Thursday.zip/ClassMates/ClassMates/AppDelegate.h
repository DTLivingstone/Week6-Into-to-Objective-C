//
//  AppDelegate.h
//  ClassMates
//
//  Created by Michael Babiy on 1/19/16.
//  Copyright © 2016 Michael Babiy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

